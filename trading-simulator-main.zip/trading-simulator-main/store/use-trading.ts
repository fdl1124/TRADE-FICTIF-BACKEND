"use client"
import { create } from "zustand"
import { assets, decisions, orders, positions, prices } from "@/lib/mock-api"
import type { View } from "@/lib/trading"
type State={view:View; selectedSymbol:string; search:string; assetType:"all"|"stock"|"crypto"; selectedDecision:string|null; agentEnabled:boolean; mode:"propose"|"autonomous"; watchlist:string[]; setView:(v:View)=>void;selectAsset:(s:string)=>void;setSearch:(s:string)=>void;setAssetType:(v:"all"|"stock"|"crypto")=>void;selectDecision:(id:string|null)=>void;toggleAgent:()=>void;setMode:(m:"propose"|"autonomous")=>void;toggleWatch:(s:string)=>void}
export const useTrading=create<State>((set)=>({view:"dashboard",selectedSymbol:"AAPL",search:"",assetType:"all",selectedDecision:null,agentEnabled:true,mode:"propose",watchlist:["AAPL","BTCUSDT","MSFT"],setView:view=>set({view}),selectAsset:selectedSymbol=>set({selectedSymbol,view:"market"}),setSearch:search=>set({search}),setAssetType:assetType=>set({assetType}),selectDecision:selectedDecision=>set({selectedDecision}),toggleAgent:()=>set(s=>({agentEnabled:!s.agentEnabled})),setMode:mode=>set({mode}),toggleWatch:s=>set(x=>({watchlist:x.watchlist.includes(s)?x.watchlist.filter(a=>a!==s):[...x.watchlist,s]}))}))
export const data={assets,decisions,orders,positions,prices}

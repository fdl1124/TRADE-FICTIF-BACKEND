import { NextResponse } from "next/server"
export async function GET(){return NextResponse.json({error:"FORBIDDEN",message:"La trace brute Gemini est réservée à l’audit backend authentifié."},{status:403,headers:{"Cache-Control":"no-store"}})}

import type { User } from "@/lib/types"

export type AuthFailure="EMAIL_EXISTS"|"WEAK_PASSWORD"|"INVALID_CREDENTIALS"
export class AuthError extends Error{constructor(public code:AuthFailure){super(code)}}
const wait=()=>new Promise(resolve=>setTimeout(resolve,650))
// BACKEND: après configuration Firebase, remplacez cet adaptateur démo par signInWithEmailAndPassword,
// createUserWithEmailAndPassword et signInWithPopup(GoogleAuthProvider). Le token ID sera fourni à lib/api.
export async function signIn(email:string,password:string):Promise<User>{await wait();if(email==="erreur@example.com"||password==="incorrect")throw new AuthError("INVALID_CREDENTIALS");return {id:"demo_user",email,displayName:email.split("@")[0],createdAt:"2026-06-04T10:00:00Z"}}
export async function signUp(email:string,password:string,name:string):Promise<User>{await wait();if(email==="existe@example.com")throw new AuthError("EMAIL_EXISTS");if(password.length<8)throw new AuthError("WEAK_PASSWORD");return {id:"demo_user",email,displayName:name,createdAt:new Date().toISOString()}}
export async function signInWithGoogle():Promise<User>{await wait();return {id:"demo_google",email:"demo@gmail.com",displayName:"Compte Google",createdAt:new Date().toISOString()}}
export const authMessage=(code:AuthFailure)=>({EMAIL_EXISTS:"Cette adresse e-mail est déjà utilisée.",WEAK_PASSWORD:"Utilisez au moins 8 caractères avec un chiffre.",INVALID_CREDENTIALS:"Adresse e-mail ou mot de passe incorrect."})[code]

# Ledger — simulateur de trading

Frontend Next.js du contrat Trading Simulator, livré avec un backend mocké et validé par Zod.

## Mode mock

Le mode mock est actif par défaut. Il simule les routes REST, la latence réseau (100–400 ms), le slippage et le flux WebSocket de prix. Aucune donnée de portefeuille dérivée n’est recalculée dans les composants : le résumé de compte reste la source de vérité.

## Basculer vers le backend réel

1. Définir `NEXT_PUBLIC_USE_MOCK_API=false`.
2. Définir `NEXT_PUBLIC_API_URL` vers l’API NestJS et `NEXT_PUBLIC_WS_URL` vers l’origine WebSocket.
3. Configurer Firebase côté client puis remplacer l’adaptateur documenté dans `lib/auth/client.ts` par le SDK Firebase. Transmettre l’ID token dans `Authorization: Bearer <firebase_id_token>` dans `lib/api/index.ts`.
4. Conserver les signatures exportées par `lib/api/index.ts` : les composants n’ont alors aucune modification à recevoir.

Les marqueurs `// BACKEND:` indiquent tous les points de substitution. La réponse brute Gemini `/api/ai/decisions/:id/raw` est réservée à l’audit technique et n’est jamais affichée dans l’interface standard.
